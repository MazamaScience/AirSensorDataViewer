## ----setup, include=FALSE, message=FALSE--------------------------------------
knitr::opts_chunk$set(fig.width=7, fig.height=5)

library(AirSensor)
library(dplyr)
library(ggplot2)

# NOTE: Use example PAS data for vignettes to avoid long wait-times
data("example_pas")
pas <- example_pas

## ---- eval=FALSE--------------------------------------------------------------
#  library(AirSensor)
#  library(dplyr)
#  library(ggplot2)
#  
#  setArchiveBaseUrl("http://smoke.mazamascience.com/data/PurpleAir")
#  
#  pas <- pas_load()

## -----------------------------------------------------------------------------
pas %>% 
  select(starts_with("pm25_")) %>% 
  head(5)

## -----------------------------------------------------------------------------
pas %>% 
  pas_leaflet()

## ----CAleaflet----------------------------------------------------------------
pas %>% 
  filter(stateCode == 'CA') %>% 
  filter(pm25_6hr >= 25.0) %>% 
  pas_leaflet(parameter = "pm25_6hr")

## -----------------------------------------------------------------------------
pas %>% 
  filter(stateCode == "CA") %>% 
  pas_leaflet(parameter = "humidity")

## ---- warning=FALSE-----------------------------------------------------------
sensorCount <- 
  pas %>% 
  count(stateCode, name="sensorCount", sort = TRUE)

gt20Count <- 
  pas %>%
  select(stateCode, pm25_1week) %>% 
  filter(pm25_1week > 20.0) %>%
  count(stateCode, sort = TRUE, name = "gt20Count")

df <-
  left_join(gt20Count, sensorCount, by = "stateCode") %>%
  mutate(gt20Fraction = gt20Count / sensorCount) %>%
  arrange(desc(gt20Fraction)) %>%
  top_n(15)

## ---- warning=FALSE-----------------------------------------------------------
df %>% 
  ggplot(aes(x = reorder(stateCode, gt20Fraction), y = gt20Fraction)) + 
  coord_flip() + 
  geom_col(aes(fill = gt20Fraction)) + 
  scale_y_continuous(labels = scales::percent) + 
  labs(x = "State", y = "Percent of PA sensors above 20 \u00B5g/m3") + 
  theme(legend.position = "none")

